let mypic=document.querySelector('#mypic');
let c=0
console.log(mypic, c);
mypic.addEventListener('click', () => {
    switch(c){
    case 0:
        mypic.src=`../images/6a46369d-a3da-4372-bf30-df59dcc7d814.jpeg`
        c=1
        break
        case 1:
            mypic.src=`../images/Picture1-1.jpg`
            c=2
            break
            case 2:
                mypic.src=`../images/scomberomorus-commerson-kebab.jpg`
                c=3
                break
                case 3:
                    mypic.src=`../images/Marinated-fish-15.jpg`
                    c=0
    }
})
let gs=document.querySelector('.gs')
let f=0
console.log(gs, f);
gs.addEventListener('click', () => {
    switch(f){
        case 0:
            gs.classList.add('w')
            f=1
            break
        case 1:
            gs.classList.remove('w')
            f=0
    }
})
let next=document.querySelector('#next')
let prev=document.querySelector('#prev')
let prods=document.querySelector('#prods')
next.addEventListener('click', () => {
    prods.scrollLeft +=90
})
prev.addEventListener('click', () => {
    prods.scrollLeft -=90
})
const autoPlay=() => {
    const maxScroll=prods.scrollWidth - prods.clientWidth
    if(prods.scrollLeft>maxScroll-1){
        prods.scrollLeft =0
    }
    else{
        prods.scrollLeft +=1
    }
}
let harekat=setInterval(autoPlay,50)
prods.addEventListener('mouseover', () => {
    clearInterval(harekat)
})
prods.addEventListener('mouseout', () => {
    return harekat=setInterval(autoPlay,50)
})
let fullname=document.querySelector('#fullname')
let email=document.querySelector('#email')
let username=document.querySelector('#username')
let pass1=document.querySelector('#pass1')
let passrepeat=document.querySelector('#passrepeat')
let form=document.querySelector('#registerform')
let erroricons=document.querySelector('.error-icons')
let checkicons=document.querySelector('.check-icons')
let erroriconsb=document.querySelector('.error-icons-b')
let checkiconsb=document.querySelector('.check-icons-b')
let erroriconsc=document.querySelector('.error-icons-c')
let checkiconsc=document.querySelector('.check-icons-c')
let erroriconsd=document.querySelector('.error-icons-d')
let checkiconsd=document.querySelector('.check-icons-d')
let erroriconse=document.querySelector('.error-icons-e')
let checkiconse=document.querySelector('.check-icons-e')
let btnsub=document.querySelector('#btnsubmit')
const emailRegex=/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
const usernameRegex=/^[A-Za-z0-9]+$/
const checkEmail=(email) => {
    return emailRegex.test(email)
}
const checkUsername=(username) => {
    return usernameRegex.test(username)
}
form.addEventListener('submit', (e) => {
    e.preventDefault()
    checkInput()
})
const checkInput=() => {
    let isValid= true
    if(fullname.value===''){
        showError(fullname, 'نام و نام خانوادگی وارد نشده است.')
        erroricons.classList.add('error')
        checkicons.classList.remove('alert')
        isValid=false
    }
    else{
        showSuccess(fullname)
        erroricons.classList.remove('error')
        checkicons.classList.add('alert')
    }
    if(email.value===''){
        showError(email, 'ایمیل وارد نشده است.')
        erroriconsb.classList.add('error')
        checkiconsb.classList.remove('alert')
        isValid=false
    }
    else if(!checkEmail(email.value)){
        showError(email, 'لطفا ایمیل خود را صحیح وارد کنید.')
        erroriconsb.classList.add('error')
        checkiconsb.classList.remove('alert')
        isValid=false
    }
    else{
        showSuccess(email)
        erroriconsb.classList.remove('error')
        checkiconsb.classList.add('alert')
    }
    if(username.value===''){
        showError(username, 'نام کاربری وارد نشده است.')
        erroriconsc.classList.add('error')
        checkiconsc.classList.remove('alert')
        isValid=false
    }
    else if(!checkUsername(username.value)){
        showError(username, 'لطفا فقط از حروف انگلیسی و اعداد استفاده کنید.')
        erroriconsc.classList.add('error')
        checkiconsc.classList.remove('alert')
        isValid=false
    }
    else if(username.value.length<8){
        showError(username, 'نام کاربری باید حداقل هشت کاراکتر داشته باشد.')
        erroriconsc.classList.add('error')
        checkiconsc.classList.remove('alert')
        isValid=false
    }
    else{
        showSuccess(username)
        erroriconsc.classList.remove('error')
        checkiconsc.classList.add('alert')
    }
    if(pass1.value===''){
        showError(pass1, 'کلمه عبور نباید خالی باشد.')
        erroriconsd.classList.add('error')
        checkiconsd.classList.remove('alert')
        isValid=false
    }
    else if(!checkUsername(pass1.value)){
        showError(pass1, 'لطفا فقط از حروف انگلیسی و اعداد استفاده کنید.')
        erroriconsd.classList.add('error')
        checkiconsd.classList.remove('alert')
        isValid=false
    }
    else if(pass1.value.length<8){
        showError(pass1, 'ورودی شما ضعیف است.')
        erroriconsd.classList.add('error')
        checkiconsd.classList.remove('alert')
        isValid=false
    }
    else{
        showSuccess(pass1)
        erroriconsd.classList.remove('error')
        checkiconsd.classList.add('alert')
    }
    if(passrepeat.value===''){
        showError(passrepeat, 'تکرار کلمه عبور نباید خالی باشد.')
        erroriconse.classList.add('error')
        checkiconse.classList.remove('alert')
        isValid=false
    }
    else if(passrepeat.value!=='' && pass1.value===''){
        showError(passrepeat, 'لطفا ابتدا کلمه عبور را در بخش بالا وارد کنید.')
        erroriconse.classList.add('error')
        checkiconse.classList.remove('alert')
        isValid=false
    }
    else if(passrepeat.value!==pass1.value){
        showError(passrepeat, 'تکرار کلمه عبور با کلمه عبور مطابقت ندارد.')
        erroriconse.classList.add('error')
        checkiconse.classList.remove('alert')
        isValid=false
    }
    if(isValid===true){
        window.location.href="http://127.0.0.1:5502/index.html"
    }
}
const showError=(input, message) => {
    const formGroup=input.parentElement
    let formText=formGroup.querySelector('.form-text')
    formText.innerText=message
    formText.classList.add('text-danger')
}
const showSuccess=(input) => {
    const formGroup=input.parentElement
    let formText=formGroup.querySelector('.form-text')
    formText.innerText=''
}
let btnred=document.querySelector('.btn-red')
let loggin=document.querySelector('.logginform')
let subform=document.querySelector('.submitform')
let one=document.querySelector('.one')
let two=document.querySelector('.two')
let rrr=document.querySelector('#rrr')
loggininput=document.querySelector('#loggininput')
two.addEventListener('click', () => {
    btnred.style.left='0'
    subform.style.display='block'
    loggin.style.display='none'
})
one.addEventListener('click', () => {
    btnred.style.left='110px'
    subform.style.display='none'
    loggin.style.display='block'
})

loggin.addEventListener('submit', (e) => {
    e.preventDefault()
    if(loggininput.value===''){
        alert('لطفا نام کاربری خود را وارد کنید.')
    }
    else if(!checkUsername(loggininput.value)){
        alert('لطفا فقط از حروف انگلیسی و اعداد استفاده کنید.')
    }
    else if(loggininput.value.length<8){
        alert('نام کاربری باید حداقل هشت کاراکتر داشته باشد.')
    }
    else{
        window.location.href="http://127.0.0.1:5501/index.html"
    }
})
let dtog=document.querySelector('.dropdown-toggle')
dtog.addEventListener('click', () => {
    dtog.style.color='white'
})
let xy = document.querySelector('.customerss');
let more = document.querySelector('.more');
more.addEventListener('click', () => {
    if (xy.style.display === 'block') {
        xy.style.display = 'none'
        more.innerText = 'نظرات بیشتر'
    } else {
        xy.style.display = 'block'
        more.innerText = 'بستن'
    }
})
let nI=document.querySelector('#nameinput')
let cI=document.querySelector('#cominput')
let fdr=document.querySelector('#fdr')
fdr.addEventListener('click', () => {
    if(nI.value===''){
        alert('نام خود را وارد کنید.')
    }
    if(cI.value===''){
        alert('دیدگاهتان را وارد کنید.')
    }
    else{
        alert('دیدگاه شما ثبت گردید.')
        nI.value=''
        cI.value=''
    }
})